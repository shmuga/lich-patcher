import { createPd, exposeControls } from "./libpd-wasm.js";

// libpd-in-the-browser demo. Picks a curated patch from manifest.json,
// loads it through the npm library, and renders a small DOM control surface.

const startBtn = document.getElementById("start");
const stopBtn = document.getElementById("stop");
const reloadBtn = document.getElementById("reload");
const patchPicker = document.getElementById("patchPicker");
const patchDesc = document.getElementById("patchDesc");
const patchSourcePanel = document.getElementById("patchSourcePanel");
const patchEl = document.getElementById("patch");
const ctrlsEl = document.getElementById("controls");
const logEl = document.getElementById("log");
const volume = document.getElementById("volume");
const volumeVal = document.getElementById("volumeVal");
const applyBtn = document.getElementById("apply");
const patchListEl = document.getElementById("pdPatchList");
const patchCountEl = document.getElementById("pdPatchCount");
const patchTitleEl = document.getElementById("pdTitle");
const patchCategoryEl = document.getElementById("pdEyebrowCat");
const patchLibraryEl = document.getElementById("pdEyebrowLib");
const sourceMetaEl = document.getElementById("pdSourceMeta");
const controlsMetaEl = document.getElementById("pdCtrlMeta");
const statusEl = document.getElementById("pdStatus");
const bundleEl = document.getElementById("pdBundle");
const libsEl = document.getElementById("pdLibs");
const scopeCanvas = document.getElementById("pd-scope");
const scopeSourceEl = document.getElementById("pdScopeSource");

const log = (message) => {
  logEl.textContent += message + "\n";
  logEl.scrollTop = logEl.scrollHeight;
};

const NOISY_PD_PRINTS = [
  /^>> [A-Za-z0-9_]+$/,
  /^<< [A-Za-z0-9_]+$/,
  /^error: \[cyclone\/[^\]]+\] is deprecated\b/,
];

function shouldShowPdPrint(text) {
  return !NOISY_PD_PRINTS.some((re) => re.test(text));
}

function renderDescription(meta) {
  patchDesc.replaceChildren();
  if (meta.description) {
    patchDesc.append(document.createTextNode(meta.description));
  }
  for (const link of meta.links || []) {
    if (!link.url || !link.label) continue;
    patchDesc.append(document.createTextNode(" "));
    const a = document.createElement("a");
    a.href = link.url;
    a.textContent = link.label;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    patchDesc.appendChild(a);
  }
}

let pd = null;
let gain = null;
let manifest = [];
let currentPatch = null;
let loadedPackages = null;
let analyser = null;
let analyserSource = null;
let analyserData = null;
let scopeContext = null;
let scopeDpr = Math.min(window.devicePixelRatio || 1, 2);
const widgetsByName = new Map();

const PACKAGES_BY_LIBRARY = {
  basic: ["vanilla"],
  vanilla: ["vanilla"],
  cyclone: ["vanilla", "cyclone"],
  else: ["vanilla", "else"],
  full: ["vanilla", "cyclone", "else"],
};

const CATEGORY_COLOR = {
  "Generative Mess": "#9B6FB8",
  Generative: "#9B6FB8",
  Effects: "#3A8AA8",
  Fundamentals: "#C6A04C",
  Sequencers: "#5E9A64",
  Ambient: "#4270A8",
  cyclone: "#C4733E",
  else: "#448F5C",
  custom: "#8A857A",
};

function packagesForPatch(patch) {
  return PACKAGES_BY_LIBRARY[patch?.library || "basic"] || ["vanilla"];
}

function packageKey(packages) {
  return [...new Set(packages)].sort().join("+");
}

function manifestPatchForFile(file) {
  return manifest.find((patch) => patch.file === file) || null;
}

function parsePickerOption(option) {
  const meta = manifestPatchForFile(option.value);
  if (meta) {
    return {
      title: meta.title,
      category: meta.category || "",
      library: meta.library || "basic",
      file: meta.file,
    };
  }

  const [title, category = ""] = option.textContent.split(" — ");
  const library = category === "cyclone" || category === "else" ? category : "basic";
  return { title, category, library, file: option.value };
}

function patchChromeMeta(patch) {
  if (patch) {
    return {
      title: patch.title || patch.file || "—",
      category: patch.category || (patch.description ? "custom" : ""),
      library: patch.library || "basic",
      file: patch.entry || patch.file || "patch.pd",
    };
  }

  const option = patchPicker.options[patchPicker.selectedIndex];
  return option
    ? parsePickerOption(option)
    : { title: "—", category: "", library: "basic", file: "patch.pd" };
}

function displayLibrary(library) {
  return library === "basic" ? "vanilla" : library;
}

function patchSlug(title) {
  return String(title || "patch")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "-");
}

function buildPatchList() {
  if (!patchListEl) return;
  patchListEl.innerHTML = "";

  for (const option of patchPicker.options) {
    const meta = parsePickerOption(option);
    const item = document.createElement("button");
    item.type = "button";
    item.className = "pd-patch";
    item.dataset.file = option.value;
    item.setAttribute("role", "option");

    const tag = document.createElement("span");
    tag.className = "pd-patch-tag";
    tag.style.background = CATEGORY_COLOR[meta.category] || "#8A857A";
    item.appendChild(tag);

    const name = document.createElement("span");
    name.className = "pd-patch-name";
    name.textContent = `[pd ${patchSlug(meta.title)}]`;
    item.appendChild(name);

    if (meta.library !== "basic") {
      const lib = document.createElement("span");
      lib.className = "pd-patch-lib";
      lib.textContent = meta.library;
      item.appendChild(lib);
    }

    item.addEventListener("click", () => {
      patchPicker.value = option.value;
      patchPicker.dispatchEvent(new Event("change", { bubbles: true }));
    });

    patchListEl.appendChild(item);
  }

  if (patchCountEl) patchCountEl.textContent = patchPicker.options.length || "—";
  syncPatchListSelection();
}

function syncPatchListSelection() {
  if (!patchListEl) return;
  for (const item of patchListEl.querySelectorAll(".pd-patch[data-file]")) {
    const active = item.dataset.file === patchPicker.value;
    item.classList.toggle("is-active", active);
    item.setAttribute("aria-selected", active ? "true" : "false");
  }
}

function syncPatchChrome(patch = currentPatch) {
  const meta = patchChromeMeta(patch);
  const category = meta.category || "patch";

  if (patchTitleEl) patchTitleEl.textContent = meta.title;
  if (patchCategoryEl) {
    patchCategoryEl.textContent = category.toLowerCase();
    patchCategoryEl.style.color = CATEGORY_COLOR[category] || "var(--ink2)";
  }
  if (patchLibraryEl) patchLibraryEl.textContent = displayLibrary(meta.library);
  if (sourceMetaEl) sourceMetaEl.textContent = meta.file;
  if (bundleEl) bundleEl.textContent = `bundle: ${meta.library}`;

  if (libsEl) {
    for (const pill of libsEl.querySelectorAll(".pd-bundle-pill")) {
      pill.classList.toggle("is-active", pill.dataset.lib === meta.library);
    }
  }

  syncPatchListSelection();
}

const startCaption = startBtn.parentElement
  ? startBtn.parentElement.querySelector(".pd-obj-cap")
  : null;
const START_LABEL = startBtn.textContent;
const START_CAPTION = startCaption ? startCaption.textContent : "";

function syncRunningChrome() {
  const running = !stopBtn.disabled;
  document.body.classList.toggle("is-running", running);

  if (running) {
    startBtn.disabled = false;
    startBtn.textContent = "[stop_audio]";
    startBtn.classList.add("pd-obj--running");
    if (startCaption) startCaption.textContent = "click to halt";
  } else {
    startBtn.textContent = START_LABEL;
    startBtn.classList.remove("pd-obj--running");
    if (startCaption) startCaption.textContent = START_CAPTION;
  }

  if (statusEl) statusEl.textContent = running ? "running" : "ready";
}

async function fetchPatchFiles(meta) {
  const paths = [meta.file, ...(meta.dependencies || [])];
  const entries = await Promise.all(
    paths.map(async (path) => {
      const response = await fetch("./" + path);
      if (!response.ok) {
        throw new Error(`failed to load ${path}: ${response.status}`);
      }
      return [path, await response.text()];
    })
  );
  const files = Object.fromEntries(entries);
  return { entry: meta.file, files, content: files[meta.file] };
}

function fileSetForPatch(patch) {
  if (patch?.files && patch?.entry) {
    return { files: patch.files, entry: patch.entry };
  }
  return { files: { "patch.pd": patch?.content || "" }, entry: "patch.pd" };
}

function setCurrentPatchContent(content) {
  if (!currentPatch) return;
  currentPatch.content = content;
  if (currentPatch.files && currentPatch.entry) {
    currentPatch.files = {
      ...currentPatch.files,
      [currentPatch.entry]: content,
    };
  }
}

function preparePatch(patch) {
  const { files, entry } = fileSetForPatch(patch);
  const prepared = exposeControls({ files, entry });
  const defaults = currentPatch?.defaults || {};
  const controls = prepared.controls.map((control) => {
    if (!(control.name in defaults)) return control;
    return { ...control, initial: [defaults[control.name]] };
  });

  return { ...prepared, entry, controls };
}

function controlsForSource(source) {
  return preparePatch({ content: source }).controls;
}

function controlInitial(control, fallback = 0) {
  const [value] = control.initial;
  if (typeof value === "number" && Number.isFinite(value)) return value;
  const parsed = Number.parseFloat(String(value ?? ""));
  return Number.isFinite(parsed) ? parsed : fallback;
}

function controlRange(control, fallbackMin = 0, fallbackMax = 1) {
  if (control.range.length === 2) return control.range;
  return [fallbackMin, fallbackMax];
}

function renderControls(controls) {
  ctrlsEl.innerHTML = "";
  for (const widget of widgetsByName.values()) {
    widget.unsubscribe?.();
  }
  widgetsByName.clear();

  if (controls.length === 0) {
    ctrlsEl.innerHTML = "<em>No controls exposed by this patch.</em>";
    setControlsLocked(!pd);
    syncRunningChrome();
    return;
  }

  for (const control of controls) {
    const row = document.createElement("div");
    row.className = "ctrl";

    const label = document.createElement("label");
    label.textContent = control.name;
    label.title = control.name;
    row.appendChild(label);

    let setValue = () => {};

    if (control.kind === "slider") {
      const [min, max] = controlRange(control);
      const initial = controlInitial(control, min);
      const input = document.createElement("input");
      input.type = "range";
      input.min = String(min);
      input.max = String(max);
      input.step = String((max - min) / 200 || 0.001);
      input.value = String(initial);

      const valueLabel = document.createElement("span");
      valueLabel.className = "val";
      valueLabel.textContent = formatVal(initial);

      input.addEventListener("input", () => {
        const value = Number.parseFloat(input.value);
        valueLabel.textContent = formatVal(value);
        pd?.sendFloat(control.name, value);
      });

      setValue = (value) => {
        input.value = String(value);
        valueLabel.textContent = formatVal(value);
      };

      row.appendChild(input);
      row.appendChild(valueLabel);
    } else if (control.kind === "number") {
      const input = document.createElement("input");
      input.type = "number";
      if (control.range.length === 2) {
        input.min = String(control.range[0]);
        input.max = String(control.range[1]);
      }
      input.value = control.initial.length ? String(controlInitial(control)) : "";
      input.addEventListener("change", () => {
        pd?.sendFloat(control.name, Number.parseFloat(input.value));
      });
      setValue = (value) => {
        input.value = String(value);
      };
      row.appendChild(input);
      row.appendChild(document.createElement("span"));
    } else if (control.kind === "bang") {
      const button = document.createElement("button");
      button.textContent = "bang";
      button.addEventListener("click", () => pd?.sendBang(control.name));
      row.appendChild(button);
      row.appendChild(document.createElement("span"));
    } else if (control.kind === "toggle") {
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = !!controlInitial(control);
      checkbox.addEventListener("change", () => {
        pd?.sendFloat(control.name, checkbox.checked ? 1 : 0);
      });
      setValue = (value) => {
        checkbox.checked = !!value;
      };
      row.appendChild(checkbox);
      row.appendChild(document.createElement("span"));
    }

    ctrlsEl.appendChild(row);

    const unsubscribe = pd?.subscribe(control.name, (message) => {
      if (message.selector === "float") setValue(message.values[0]);
    });
    widgetsByName.set(control.name, { setValue, unsubscribe });
    sendInitialControlValue(control);
  }

  setControlsLocked(!pd);
  syncRunningChrome();
}

function sendInitialControlValue(control) {
  if (!pd || control.kind === "bang" || control.initial.length === 0) return;
  const value = control.initial[0];
  if (typeof value === "number") {
    pd.sendFloat(control.name, value);
  } else {
    pd.sendSymbol(control.name, value);
  }
}

function setControlsLocked(locked) {
  ctrlsEl.classList.toggle("locked", locked);
  for (const el of ctrlsEl.querySelectorAll("input, button")) {
    el.disabled = locked;
  }
}

function formatVal(value) {
  const number = Number.parseFloat(String(value));
  if (!Number.isFinite(number)) return String(value);
  if (Math.abs(number) >= 100) return number.toFixed(0);
  if (Math.abs(number) >= 1) return number.toFixed(2);
  return number.toFixed(3);
}

function resizeScope() {
  if (!scopeCanvas) return;
  const bounds = scopeCanvas.getBoundingClientRect();
  scopeDpr = Math.min(window.devicePixelRatio || 1, 2);
  scopeCanvas.width = Math.max(200, Math.floor(bounds.width * scopeDpr));
  scopeCanvas.height = Math.max(160, Math.floor(bounds.height * scopeDpr));
}

function initScope() {
  if (!scopeCanvas) return;
  scopeContext = scopeCanvas.getContext("2d");
  resizeScope();
  window.addEventListener("resize", resizeScope);
  if ("ResizeObserver" in window) {
    new ResizeObserver(resizeScope).observe(scopeCanvas);
  }
  requestAnimationFrame(drawScope);
}

function startScope(audioContext, sourceNode) {
  if (!scopeCanvas) return;
  stopScope();
  const moreGain = pd.audioContext.createGain();
  moreGain.gain.value = 25.0;
  try {
    analyser = audioContext.createAnalyser();
    analyser.fftSize = 1024*2;
    analyser.smoothingTimeConstant = 1.0;
    sourceNode.connect(moreGain);
    moreGain.connect(analyser);
    analyserSource = sourceNode;
    analyserData = new Float32Array(analyser.fftSize);
    if (scopeSourceEl) scopeSourceEl.textContent = "analyser";
  } catch {
    analyser = null;
    analyserSource = null;
    analyserData = null;
    if (scopeSourceEl) scopeSourceEl.textContent = "synthetic";
  }
}

function stopScope() {
  if (analyserSource && analyser) {
    try {
      analyserSource.disconnect(analyser);
    } catch {
      // The node may already have been disconnected as part of patch teardown.
    }
  }
  if (analyser) {
    try {
      analyser.disconnect();
    } catch {
      // An analyser used as a graph tap may not have downstream connections.
    }
  }
  analyser = null;
  analyserSource = null;
  analyserData = null;
  if (scopeSourceEl) scopeSourceEl.textContent = "synthetic";
}

function drawScope() {
  if (!scopeCanvas || !scopeContext) return;

  const running = !stopBtn.disabled;
  const width = scopeCanvas.width;
  const height = scopeCanvas.height;
  scopeContext.fillStyle = "#070A08";
  scopeContext.fillRect(0, 0, width, height);

  scopeContext.strokeStyle = "rgba(214,234,224,0.07)";
  scopeContext.lineWidth = 1;
  for (let index = 1; index < 4; index += 1) {
    scopeContext.beginPath();
    scopeContext.moveTo(0, (height / 4) * index);
    scopeContext.lineTo(width, (height / 4) * index);
    scopeContext.stroke();
  }
  for (let index = 1; index < 8; index += 1) {
    scopeContext.beginPath();
    scopeContext.moveTo((width / 8) * index, 0);
    scopeContext.lineTo((width / 8) * index, height);
    scopeContext.stroke();
  }

  scopeContext.strokeStyle = "rgba(214,234,224,0.16)";
  scopeContext.beginPath();
  scopeContext.moveTo(0, height / 2);
  scopeContext.lineTo(width, height / 2);
  scopeContext.stroke();

  if (analyser && analyserData) {
    analyser.getFloatTimeDomainData(analyserData);
    scopeContext.lineWidth = 1.6 * scopeDpr;
    scopeContext.strokeStyle = "#E8C547";
    scopeContext.beginPath();
    const slice = width / analyserData.length;
    for (let index = 0; index < analyserData.length; index++) {
      const value = (analyserData[index] + 1.0) / 2.0;
      const x = index * slice;
      const y = height / 2 * (height * 0.42*10.0);
      if (index === 0) scopeContext.moveTo(x, y);
      else scopeContext.lineTo(x, y);
    }
    scopeContext.stroke();
  }
  drawSyntheticScope(width, height, running, analyserData);

  requestAnimationFrame(drawScope);
}

let syntheticScopeTime = 0;
let heightScale = 1.0;

function drawSyntheticScope(width, height, running, analyserData) {
  syntheticScopeTime += running ? 0.05 : 0.05;
  const ampScale = running ? 0.17 : 0.17;
  const layers = [
    { freq: 4*1.0, amp: 0.22*0.5*1.5, off: 0, color: "#E8C547" },
    { freq: 9*2.0, amp: 0.1*0.5*1.0, off: 1.7, color: "#6AD4B8" },
    { freq: 4*1.0, amp: 0.1*0.5*1.0, off: 1.7, color: "#f3e928" },
    { freq: 17*1.0, amp: 0.05*0.5*0.5, off: 3.4, color: "#9B6FB8" },
  ];

  heightScale += 0.005;
  heightScale = Math.min(heightScale, 7.0);

  for (const layer of layers) {
    let value = 1.0;
    let i = 0;
    scopeContext.beginPath();
    for (let x = 0; x <= width; x += scopeDpr) {
      if (analyserData && analyserData.length && i<analyserData.length) {
        value = (analyserData[i] + 1.0) / 2.0;
        value *= heightScale;
        i++;
      }
      const phase = (x / width) * Math.PI * layer.freq;
      const y =
        height / 2 +
        Math.sin(phase + syntheticScopeTime + layer.off) *
          (height * layer.amp * ampScale) +
        Math.sin(phase * 2.1 + syntheticScopeTime * 1.3 + layer.off) *
          (height * layer.amp * 0.4 * ampScale*value);
      if (x === 0) scopeContext.moveTo(x, y*1.0);
      else scopeContext.lineTo(x, y);
    }
    scopeContext.strokeStyle = layer.color;
    scopeContext.lineWidth = 1.6 * scopeDpr;
    scopeContext.globalAlpha = running ? 0.9 : 0.9;
    scopeContext.stroke();
  }
  scopeContext.globalAlpha = 1;
}

async function start() {
  startBtn.disabled = true;

  if (!currentPatch && manifest.length) {
    await selectPatch(manifest[0]);
  }
  if (!currentPatch) {
    log("no patch selected");
    startBtn.disabled = false;
    return;
  }

  const packages = packagesForPatch(currentPatch);
  loadedPackages = packageKey(packages);
  log(`loading ${currentPatch.title || currentPatch.file}`);
  log(`worklet module loading (${loadedPackages})`);

  const prepared = preparePatch(currentPatch);

  pd = await createPd({
    packages,
    files: prepared.files,
    entry: prepared.entry,
    onPrint: (text) => {
      if (shouldShowPdPrint(text)) log("pd: " + text);
    },
    onError: (error) => log("error: " + error.message),
  });

  log(`AudioContext sampleRate=${pd.audioContext.sampleRate}`);
  log("patch opened");

  gain = pd.audioContext.createGain();
  gain.gain.value = Number.parseFloat(volume.value);
  pd.node.connect(gain);
  gain.connect(pd.audioContext.destination);
  startScope(pd.audioContext, gain);

  renderControls(prepared.controls);

  stopBtn.disabled = false;
  reloadBtn.disabled = false;
  syncRunningChrome();
}

async function stop() {
  for (const widget of widgetsByName.values()) {
    widget.unsubscribe?.();
  }
  widgetsByName.clear();
  stopScope();
  gain?.disconnect();
  gain = null;
  await pd?.close();
  pd = null;
  loadedPackages = null;
  setControlsLocked(true);
  startBtn.disabled = false;
  stopBtn.disabled = true;
  reloadBtn.disabled = true;
  syncRunningChrome();
}

async function loadCurrentPatch() {
  if (!pd || !currentPatch) return;
  patchEl.value = currentPatch.content;
  const prepared = preparePatch(currentPatch);
  log(`loading ${currentPatch.title || currentPatch.file}`);
  await pd.loadPatch({
    files: prepared.files,
    entry: prepared.entry,
  });
  log("patch opened");
  renderControls(prepared.controls);
}

async function selectPatch(meta) {
  const patchFiles = await fetchPatchFiles(meta);
  currentPatch = { ...meta, ...patchFiles };
  patchEl.value = currentPatch.content;
  renderDescription(meta);
  syncPatchChrome(currentPatch);
  renderControls(preparePatch(currentPatch).controls);
}

async function init() {
  try {
    manifest = await fetch("./manifest.json").then((response) => response.json());
  } catch (error) {
    log("failed to load manifest.json: " + error);
    return;
  }

  for (const patch of manifest) {
    const option = document.createElement("option");
    option.value = patch.file;
    option.textContent = patch.category
      ? `${patch.title} — ${patch.category}`
      : patch.title;
    patchPicker.appendChild(option);
  }
  buildPatchList();

  if (manifest.length) {
    patchPicker.value = manifest[0].file;
    await selectPatch(manifest[0]);
  }
  syncPatchChrome(currentPatch);
}

startBtn.addEventListener(
  "click",
  (event) => {
    if (!stopBtn.disabled) {
      event.stopImmediatePropagation();
      event.preventDefault();
      stopBtn.click();
    }
  },
  true
);

startBtn.addEventListener("click", () => {
  start().catch((error) => {
    log("error: " + error.message);
    startBtn.disabled = false;
    syncRunningChrome();
  });
});

stopBtn.addEventListener("click", () => {
  stop().catch((error) => log("error: " + error.message));
});

patchPicker.addEventListener("change", async () => {
  const meta = manifest.find((patch) => patch.file === patchPicker.value);
  if (!meta) return;

  await selectPatch(meta);
  if (!pd) return;

  const nextPackages = packageKey(packagesForPatch(meta));
  if (nextPackages !== loadedPackages) {
    log(`library switch: ${loadedPackages} -> ${nextPackages} (restarting audio)`);
    await stop();
    await start();
  } else {
    await loadCurrentPatch();
  }
});

reloadBtn.addEventListener("click", () => {
  setCurrentPatchContent(patchEl.value);
  loadCurrentPatch().catch((error) => log("error: " + error.message));
});

applyBtn.addEventListener("click", () => {
  if (!currentPatch) {
    currentPatch = {
      file: "edit.pd",
      title: "edit.pd",
      description: "(edited)",
      content: patchEl.value,
      files: { "edit.pd": patchEl.value },
      entry: "edit.pd",
    };
    renderDescription(currentPatch);
  } else {
    setCurrentPatchContent(patchEl.value);
  }
  syncPatchChrome(currentPatch);

  if (pd) {
    loadCurrentPatch().catch((error) => log("error: " + error.message));
  } else {
    renderControls(controlsForSource(patchEl.value));
  }
});

volume.addEventListener("input", () => {
  const value = Number.parseFloat(volume.value);
  volumeVal.textContent = value.toFixed(2);
  if (gain) gain.gain.value = value;
});

function setPatchDropState(dropping) {
  patchSourcePanel.classList.toggle("dropping", dropping);
  patchEl.classList.toggle("dropping", dropping);
}

patchSourcePanel.addEventListener("dragover", (event) => {
  event.preventDefault();
  patchSourcePanel.open = true;
  setPatchDropState(true);
});

patchSourcePanel.addEventListener("dragleave", (event) => {
  if (patchSourcePanel.contains(event.relatedTarget)) return;
  setPatchDropState(false);
});

patchSourcePanel.addEventListener("drop", async (event) => {
  event.preventDefault();
  setPatchDropState(false);
  const file = event.dataTransfer.files[0];
  if (!file) return;

  const text = await file.text();
  patchEl.value = text;
  currentPatch = {
    file: file.name,
    title: file.name,
    description: "(dropped) " + file.name,
    content: text,
    files: { [file.name]: text },
    entry: file.name,
  };
  renderDescription(currentPatch);
  syncPatchChrome(currentPatch);

  if (pd) {
    await loadCurrentPatch();
  } else {
    renderControls(controlsForSource(text));
  }
});

initScope();
syncRunningChrome();
init();
