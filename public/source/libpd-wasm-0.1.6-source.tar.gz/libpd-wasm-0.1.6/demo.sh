#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

scripts/clean
scripts/build-demo-lib
scripts/build-wasm
scripts/serve "${1:-8000}"
