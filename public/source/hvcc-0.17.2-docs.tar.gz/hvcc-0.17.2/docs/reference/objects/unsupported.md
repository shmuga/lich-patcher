# Unsupported objects

These are all the objects that hvcc is not able to parse. It will give errors if you use them.

> [!NOTE]
> This list is non-exhaustive and not fully up to date. Please report any missing pd-vanilla objects.

Here is a list of [supported Pd objects](supported.md).

## Message Objects

| object |
| ------ |
| append |
| array |
| bag |
| choice |
| clone |
| cputime |
| drawcurve |
| drawnumber |
| drawpolygon |
| drawsymbol |
| drawtext |
| element |
| file |
| filledcurve |
| filledpolygon |
| fudiformat |
| fudiparse |
| get |
| getsize |
| glist |
| key |
| keyname |
| keyup |
| makefilename |
| namecanvas |
| netreceive |
| netsend |
| openpanel |
| oscformat |
| oscparse |
| plot |
| pointer |
| qlist |
| realtime |
| savepanel |
| savestate |
| scalar |
| set |
| setsize |
| soundfiler |
| stdout |
| struct |
| sysexin |
| tabread4 |
| template |
| text |
| textfile |
| trace |
| v |
| value |

## Signal Objects

| object |
| ------ |
| bob~ |
| bonk~ |
| fexpr~ |
| fft~ |
| framp~ |
| ifft~ |
| log~ |
| loop~ |
| lrshift~ |
| pd~ |
| print~ |
| readsf~ |
| rfft~ |
| rifft~ |
| scope~ |
| sigmund~ |
| switch~ |
| slop~ |
| tabreceive~ |
| tabsend~ |
| vline~ |
| vsnapshot~ |
| writesf~ |
